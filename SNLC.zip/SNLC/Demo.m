clc, clear, close all
d   = 2;                   % Dimension
N   = 100;                 % Number of sensors
K   = 10;                  % Number of anchors
r   = 0.4;                 % Radio range
X   = rand(d,N+K)-0.5;
nsd = 0.01;                   % Noise standard deviation
G   = squareform(pdist(X'));
DD  = zeros(length(G));
for i = 1:(N+K-1)
    for j = (i+1):(N+K)
        if G(i,j) < r
            if i > N
                DD(i,j) = G(i,j);
                DD(j,i) = DD(i,j);
            else
                DD(i,j) = abs(1+nsd*randn(1))*G(i,j);
                DD(j,i) = DD(i,j);
            end
        end
    end
end
DD1= DD(1:N,:);
if K > 0
    Xa = X(:,N+(1:K));
else
    Xa = [];
end
X = X(:,1:N);
[XEST,Time]  = SNLC(DD,Xa,d);
[Y,RMSE,~,~] = Globalregistration_Arun(XEST,X);
if size(Xa,2) < (d+1)
    figure(1), plotpositions(Xa,X,Y)
else
    figure(1), plotpositions(Xa,X,XEST)
end
X0  = sum(X,2)/N;
Y0  = X-X0*ones(1,N);
f   = norm(Y0,'fro')/sqrt(N);
ANE = RMSE/f;
disp('ANE:')
disp(ANE)
disp('Run-time:')
disp(Time)