%% ************************************************************************
%% Code Description:-
%  Recover O(d) from W
%% Input :-
%  W: A d-by-Md or d-by-(M+1)d matrix
%% Output:-
%  O: A d-by-Md or d-by-(M+1)d matrix where each d-by-d block is orthogonal
%     matrix.
%% ************************************************************************
function O = Odrecovery(W)
    if nargin ~= 1
        error('Number of input argument should be one.')
    end
    [d,M] = size(W);
    M     = M/d;
    O     = zeros(d,M*d);
    for i = 0:(M-1)
        [U2,~,V2] = svd(W(1:d,i*d+(1:d)));
        O(1:d,i*d+(1:d)) = U2*V2';
    end
end