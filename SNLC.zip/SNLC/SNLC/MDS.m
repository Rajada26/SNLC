%% ************************************************************************
%% Code Description:
%  Multi-dimensional scaling (MDS) - applicable only for complete graph
%% Input:-
%  E: Edge matrix
%  d: Dimension of the space where sensors are embedded
%% Output:-
%  Y: The estimated position
%% ************************************************************************
function Y = MDS(E,d)
    if nargin ~= 2
        error('There must be two input arguments to this function.')
    end
    n = length(E);
    if sum(diag(E) == 0) ~= n
        error('Diagonal of the matrix is not zero.')
    end
    if sum(sum(E ~= 0)) ~= n^2-n
        error('The graph is not a clique.');
    end
    D = E.^2;
    eet = ones(n,n);
    H = eye(n)-(1/n)*eet;
    B = -0.5*H*D*H;
    % Note: Due to numerical precision, if B is not coming symmetric,
    %       because of that we are doing-
    B = (B+B')/2; 
    [V,e] = eig(B);
    [e,I] = sort(diag(e),'descend');
    e     = e(1:d);
    e     = max(e,0);
    e     = diag(e);
    V     = V(:,I(1:d));
    Y     = sqrt(e)*V';
end