function Clq = Clique_Create(A)
    %% Creating cliques by extracting max clique from the neighborhood
    %  graph of each node
    %% Variable defining
    N        = length(A);
    NodeIdxi = cell(N,1);
    Ai       = cell(N,1);
    %node     = 1:N;
    MaxiClq  = cell(N,1);
    A1       = A+eye(N);                           % A1: Graph + Self edges
    %% Finding max cliques of the neighborhood graphs of each of the nodes
    for i = 1:N
        [~,NodeIdxi{i},~] = find(A1(i,:));
        Ai{i} = A(NodeIdxi{i},NodeIdxi{i});
    end
    parfor i = 1:N
        MaxiClq{i} = MaximalClqNi(Ai{i},NodeIdxi{i});
    end
    %% Storing the result
    Clq       = cell(1);
    LenClq    = cell(1);
    Clq{1}    = MaxiClq{1};
    LenClq{1} = length(MaxiClq{1});
    j = 1;
    for i = 2:N
        C = MaxiClq{i};
        L = length(C);
        flag = 1;
        for k = 1:j
            if L == LenClq{k};
                if sum(Clq{k}-C ~= 0) == 0
                    flag = 0;
                    break
                end
            end
        end
        if flag == 1
            j = j+1;
            Clq{j}    = C;
            LenClq{j} = L;
        end
    end
end