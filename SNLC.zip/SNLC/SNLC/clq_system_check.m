function P = clq_system_check(P,d,N,A)
%% Code Description:
%  To check how good is the clique system.
%% Input:
%  P: Cell contains points from different cliques
%  d: Dimension of the space
%  N: Number of sensors
%  A: Adjacency matrix of the measurement graph
%% Output:
%  P: Modified clique system
if nargin ~= 4
    error('Number of inputs must be four.');
end
K = length(A)-N;                    % K: Number of anchors
%% Bipartite graph:
%% One side contains nodes from 1 to (N+K)
%% Other side contains nodes from (N+K+1) to (N+K+M+1)/(N+K+M)
%  N: Number of sensors
%  K: Numbr of anchors
M0 = length(P);                     % M0 : Initial number of cliques
M  = M0;                            % M  : Number of cliques
%  P1: Clique points
if K > 0
    P1 = (N+K)+(1:(M+1));           % with anchor case
else
    P1 = N+(1:M);                   % without anchor case
end
%% Create the bipartite graph for rigidity checking
Adj  = cell(M,1);
parfor i = 1:M
    Adj{i} = sparse(1,P{i},1,1,N+K);
end
if K > 0
    Adj{M+1} = sparse(1,N+(1:K),1,1,N+K);
end
Adj = cell2mat(Adj);
Adj = [zeros(N+K) Adj'; Adj zeros(P1(end)-N-K)];
%% Clique size checking
for i = 1:M
    if length(P{i}) < (d+1)
        error('ERROR: Clique size < (d+1) ... No performance guarantee');
    end
end
%% Testing and recovery phase (if that is possible)
%% Sensors which are belong to more than one clique
[~,n1,~] = find(sum(Adj(:,1:N),1) > 1); % n1 : Interesting sensors
if K ~= 0
    n1 = [n1 N+(1:K)];
end
%% Checking for the min cut such that source and sink are from the cliques
for i = 2:M0
    flag = (i-1);
    while flag > 0
        if flag == 1
            %% Extract important part
            Ind = [n1 P1];
            N1  = length(n1);
            N2  = length(Ind);
            %% Change Adjacence Matrix: Introduce Vertex Capacity
            %[II,JJ,VAL] = find(Adj(Ind,Ind));
            %Adj1 = sparse(II,JJ,VAL,N2,N2);
            [II,JJ,~] = find(Adj(Ind(1:N1),Ind((N1+1):N2)));
            Adj1 = sparse(2*(1:N1)-1,2*(1:N1),1,N1+N2,N1+N2)+ ...
                   sparse(2*II,2*N1+JJ,1,N1+N2,N1+N2)+ ...
                   sparse(2*N1+JJ,2*II-1,1,N1+N2,N1+N2);
        end
        %% Flow Algorithm
        [flowval,Cut,~,~] = max_flow(Adj1,(1+2*N1),(i+2*N1));
        if flowval < (d+1)
            %% Rectification of the min-cut
            MaxClq = clq_sys_rect(Cut,A,Adj,N1,M,d);
            if isempty(MaxClq)
                disp('Warning: Clique sytem is not good.');
                flag = 0;
            else
                flag = 1;
                %% Update the bipartite graph
                M    = M+1;
                P{M} = MaxClq;
                n1   = union(MaxClq,n1);
                if K > 0
                    P1 = [P1 (N+K+M+1)];
                    %% Adjacency matrix update
                    dummy = sparse(MaxClq,1,1,(N+K+M),1);
                    Adj = [Adj dummy; dummy' zeros(1)];
                    Adj(:,[end-1 end]) = Adj(:,[end end-1]);
                    Adj([end-1 end],:) = Adj([end end-1],:);
                else
                    P1 = [P1 (N+K+M)];
                    %% Adjacency matrix update
                    dummy = sparse(MaxClq,1,1,(N+M-1),1);
                    Adj = [Adj dummy; dummy' zeros(1)];
                end
            end
        else
            flag = 0;
        end
    end
end
end