%% Solving GRET-SDP or GRET-SPEC.
%% Inputs:-
%  P    : Set of all points in ith patch
%  PLoc : Position of all the points in ith patch
%  Flag : Denote whether the network contains any anchor 
%         0 - no anchor; 1 - with anchor
%  N    : Total number of sensors
%% Output:-
%  J: N+M-by-N+M matrix (or)  N+M   -by- N+M    matrix
%  B: M*d-by-N+M matrix (or) (M+1)*d-by- N+M    matrix
%  D: M*d-by-M*d matrix (or) (M+1)*d-by-(M+1)*d matrix
%% ************************************************************************
function [J1,J2,B1,B3,D1,D2] = Compute_matices(P,PLoc,N,lam)
    if nargin ~= 4
        error('Number of inputs must be four.')
    end    
    %% Parameters
    [d,N1] = size(PLoc);                  % Dimension and No. of nodes
    %% Data Processing
    if size(P,1) > size(P,2)
        P = P';
    end
    s   = P <= N;
    a   = not(s);
    Ns  = sum(s);
    sen = P(s);
    Xs  = PLoc(:,s);
    %% Matrix Computation
    %% J Calculation
    J1 = sparse(sen,1,1,N,1);
    J2 = Ns;
    Na = N1-Ns;
    J2 = J2+lam*Na;
    %% B Calculation
    B1 = sparse(repmat((1:d)',1,Ns),repmat(sen,d,1),Xs,d,N);
    if lam ~= 0
        Xa = PLoc(:,a);
        B3 = lam*sum(Xa,2);
    else
        B3 = zeros(d,1);
    end
    %% D Calculation
    D1 = zeros(d);
    if lam ~= 0
        D2 = zeros(d);
    else
        D2 = [];
    end
    ita = max(Ns,Na);
    for i = 1:ita
        if i <= Ns
            Seni = Xs(:,i);
            D1   = D1+Seni*Seni';
        end
        if i <= Na
            Anchi = Xa(:,i);
            D2 = D2+Anchi*Anchi';
        end
    end
    if lam ~= 0
        D2 = -lam*D2;
        D1 = D1-D2;
    end
end