%% ************************************************************************
%  This code is a part of the clique finding algorithm.
%% Description:-
%  Extract clique from the adjacency matrix A and a vector u: the indices
%  are selected one at a time, correpsonding to the largest entries of u. 
%% Acknowledgement:-
%  This code is downloaded from the below website-
%  https://sites.google.com/site/nicolasgillis/code
%  Some minor modifications are done by Rajat Sanyal.
%% ************************************************************************
function J = extract_clique(A,u)
    n = length(A); 
    [~,II] = sort(-u); % sort in nonincreasing order
    J = II(1); 
    i = 2; 
    % Select indices, one at a time, until the corresponding set is not a 
    % clique
    while (i <= n) && (min(A(II(i), J)) > 0) 
        J = [J II(i)];
        i = i + 1; 
    end
    J = J';
end