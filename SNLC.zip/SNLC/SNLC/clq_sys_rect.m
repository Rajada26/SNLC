function MaxClq = clq_sys_rect(Cut,A,Adj,N1,M,d)
    %% Code Description:
    %  This code can be used to rectify the patch system.
    %% Input:
    %  Cut: A column vector; entries are either +1 or -1
    %  A  : Adjacency matrix of the measurement graph
    %  Adj: Adjacency matrix of the bipartite graph
    %  N1 : Effective number of nodes
    %  M  : Total number of patches (except virtual anchor patch)
    %  d  : Dimension of the space
    %% Output:
    %  MaxClq: Maximal clique
    if nargin ~= 6
        error('Number of inputs must be six.');
    end
    %% Initialization phase
    N1     = N1*2;
    NK     = length(A);            % Total number of nodes
    MaxClq = [];
    %% Distinguish between two parts of the cut
    [P_C1,~,~] = find(Cut(N1+(1:M)) == 1);
    [P_C2,~,~] = find(Cut(N1+(1:M)) == -1);
    %% Nodes belong to patches of C1
    [~,node1,~] = find(sum(Adj(P_C1+NK,1:NK),1) ~= 0);
    %% Nodes belong to patches of C2
    [~,node2,~] = find(sum(Adj(P_C2+NK,1:NK),1) ~= 0);
    %% Nodes belong to patches of both C1 and C2
    node3 = intersect(node1,node2);
    %% Nodes belong to only patches of C1
    node1 = setdiff(node1,node3);
    %% Nodes belong to only patches of C2
    node2 = setdiff(node2,node3);
    %% Nodes which has an edge from node1 to node2 in measurement graph
    A_ext = A(node1,node2);
    [I1,J1,~] = find(A_ext);
    len   = length(I1);
    i     = 0;
    while i < len
        i      = i+1;
        MaxClq = rect_max_clq(A,node1(I1(i)),node2(J1(i)),d);
        if ~isempty(MaxClq)
            break
        end
    end 
end