%% ************************************************************************
%% Code Description:-
%  Implementation of- "Least Square Fitting of Two Point Sets" by K.S.Arun,
%  T.S. Huang, S.D. Blostein
%% Input:-
%  X and X_est are d-by-n matrix where d = dimension of the space
%  where nodes are embedded, and n = number of sensor nodes
%% Output:-
%  Y: After Arun, the new estimated positions of the nodes
%  err: RMSD error
%  O_s: Optimal orthogonal matrix
%  t_s: Optimal translation
%% ************************************************************************
function [Y,err,O_s,t_s] = Globalregistration_Arun(X_est,X)
    if nargin ~= 2
        error('Number of inputs must be two.')
    elseif all(size(X) == size(X_est)) ~= 1
        error('Dimension mismatch');
    end
    [d,n] = size(X);
    Xc = sum(X,2)/n;                   % Centroid of the original data
    X1 = X-Xc*ones(1,n);               % Original data set wrt to centroid
    Xc_est = sum(X_est,2)/n;           % Centroid of the estimated data
    X2 = X_est-Xc_est*ones(1,n);       % Estimated data set wrt to centroid
    C = zeros(d);
    for i = 1:n
        C = C+X2(:,i)*X1(:,i)';
    end
    [U,~,V] = svd(C);
    O_s = V*U';
    t_s = Xc-O_s*Xc_est;
    err = 0;
    Y = O_s*X_est+t_s*ones(1,n);
    for i = 1:n
        err = err+norm(Y(:,i)-X(:,i))^2;
    end
    err  = err/n;
    err  = sqrt(err);
end