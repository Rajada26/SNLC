function MaxClq = MaximalClqNi(A,NodeIdx)
    %% Function Description
    %  Finding a maximal clique from the neighborhood graph of ith node
    %% Input:
    %  A      : Adjacency matrix of ith point
    %  NodeIdx: Indices of the neighbor points of i
    %% Output:
    %  MaxClq : Maximum clique
    %% Pre-processing
    [~,Idx] = sort(sum(A));
    NodeIdx = NodeIdx(Idx);
    A = A(Idx,Idx);
    %% Find cliques using the Belachew-Gillis algorithm
    N = length(A);
    B = A+eye(N);
    [~,Idx,~] = cliquefindAlg(B);        % At this point, this is a clique.
    if size(Idx,1) > size(Idx,2)
        Idx = Idx';
    end
    %% Grow the clique to get a maximal clique
    othrnode = setdiff(1:N,Idx);
    N = length(Idx);
    while ~isempty(othrnode)
        A1  = A(Idx,othrnode);
        [deg,pos] = max(sum(A1,1));
        if deg == N
            N   = N+1;
            Idx = [Idx othrnode(pos)];
            othrnode = othrnode((1:end) ~= pos);
        else
            break
        end
    end
    MaxClq = sort(NodeIdx(Idx));
end