function MaxClq = rect_max_clq(A,node1,node2,d)
    %% Code Description:
    %% Find a maximal clique containing node1 and node2
    %% Input :
    %  A    : Adjacency matrix of the sensor graph
    %  node1: A node
    %  node2: A node
    %  d    : Dimension
    %% Output:
    %  MaxClq: Maximal clique
    if nargin ~= 4
        error('Number of inputs must be 4.');
    end
    %% Initial calculation
    MaxClq = [];            % MaxClq: Maximal clique of size greater than d
    %% Finding one-hop common neighbors of node1 and node2
    [~,J1,~] = find(A(node1,:) ~= 0);   % J1: Negibourhood nodes of node1
    [~,J2,~] = find(A(node2,:) ~= 0);   % J2: Negibourhood nodes of node2
    J1       = intersect(J1,J2);        % J1: Common negibourhood nodes
    if ~isempty(J1)
        disp('New patch is created.');
        %% Clique finding phase
        A  = A(J1,J1);                  % A : Extracted adjacency matrix
        N  = length(J1);                % N : Number of effective nodes
        B  = A+eye(N);                  % B : Matrix for the clique finding
        [~,J2,~] = cliquefindAlg(B);    % J2: A clique
        if size(J2,1) > size(J2,2)
            J2 = J2';
        end
        J3 = setdiff(1:N,J2);           % J3: Other nodes not in clique
        N  = length(J2);                % Size of the clique
        while ~isempty(J3)
            [Max_deg,Pos] = max(sum(A(J2,J3),1));
            if Max_deg == N
                N  = N+1;
                J2 = [J2 J3(Pos)];
                J3 = J3((1:end) ~= Pos);
            else
                break
            end
        end
        if N > (d-2)
            MaxClq = sort([J1(J2),node1,node2]);
        end
    end
end