%% ************************************************************************
%  This code is based on the clique finding algorithm presented in the 
%  article
%  'Solving the maximum clique problem with symmetric rank-one nonnegative
%  matrix approximation' - Melisew Tefera Belachew and Nicolas Gillis, 2015
%% Description:-
%  It tries to solve a particular symmetric rank-one nonnegative matrix
%  approximation problem: 
%               min_{u >= 0} ||M - uu^T||_F^2 , 
%  where M = (1+d) B - 1_{n x n} with B being the modified adjacency matrix 
%  of the graph (that is, with ones on the diagonal). It uses a projected
%  gradient method with the Armijo procedure to compute the step length.
%  The code takes the modified binary adjacency matrix B of an undirected 
%  graph G as an input and outputs a clique of G. It also works if the 
%  graph is weighted.
%% Inputs:-
%  B       - an n-by-n binary adjacency matrix with nonzero on the diagonal
%  u0      - initial guess (default: rand(n,1))
%  maxiter - maximum number of iteration (default: 1000)
%  d       - a parameter initialized (default: 0.2(sqrt(nnz)/(nz)))
%  gamma   - a positive constant to slowly update d (default: 1.1)
%  D       - an upper bound for d (default: 2*n*||B||_F^2)
%% Outputs:- 
%  u       - final iterate of the gradient descent scheme
%  I       - index set that contains the indices corresponding to a clique
%  clqsize - clique size
%% Acknowledgement:-
%  This code is downloaded from the below website-
%  https://sites.google.com/site/nicolasgillis/code
%  Some minor modifications are done by me.
%% ************************************************************************
function [u,I,clqsize] = cliquefindAlg(B,u0,maxiter,d,gamma,D)
    n   = length(B);
    tol = 1e-6;
    % Parameters for Armijo: these parameters correspond to the ones used
    % in the modified Armijo procedure (see the paper for more details). 
    % Namely:-
    %    - alpha          : step-size
    %    - beta and sigma : range between 0 and 1
    %    - upperboundalpha: upper-bound for the number of trials
    %                       (per iteration) in searching for step-sizes
    %                        that satisfy the modified Armijo condition
    %    - upperboundupdt : upper-bound for the number of times 
    %                      (per iteration)one needs to tune the parameter d
    beta  = 0.5;
    sigma = 0.01;
    upperboundalpha = 5;
    upperboundupdt  = 5;
    if min(diag(B) > 0) == 0
        error('The diagonal entries of B are not positive.')
    end
    sB = sum(B(:));
    if nargin <= 1, u0 = rand(n,1); end
    if nargin <= 2, maxiter = 1000; end
    if nargin <= 3, d = max(1/n^2,0.2*sqrt(sB/max(1,(n^2-sB)))); end
    if nargin <= 4, gamma = 1.1; end
    if nargin <= 5, D = 2*n*(norm(B,'fro')); end
    % One step of power method to have a good scaling of u, particularly 
    % important when B is not binary
    u = B*u0/norm(u0,2)^2;
    % If B is not binary, to be able to compute M*u, the following can be
    % used:-
    % M*u = B*u+d*Bbin*u-d*ones(n,1)*sum(u)
    % where Bbin = double(B > 0) 
    % instead of 
    % M*u = (1+d)*B*u-d*ones(n,1)*sum(u)
    maxB = max(B(B > 0)); 
    minB = min(B(B > 0)); 
    if maxB == minB          % B is binary, possibly up to a scaling factor
        B(B > 0) = 1; 
        bbbin = 1; 
    else
        Bbin = double(B > 0);   
        bbbin = 0; 
    end
    for k = 1:maxiter
        if bbbin == 1
            MU = ((1+d)*(B*u)-d*ones(n,1)*sum(u));
        else
            MU = (B*u+d*Bbin*u-d*ones(n,1)*sum(u));
        end
        utu = u'*u;
        grad_u = -2*(MU-utu*u);
        Fold   = -u'*MU+0.5*utu^2;
        if k == 1
            alpha = 0.1*norm(u)/norm(grad_u);
        end
        tol_grad = norm(grad_u(grad_u < 0 | u > 0));
        if tol_grad < tol
            break
        end
        s = 0;
        cond_alpha = 0;
        % Searching for step-size that satisfies the modified Armijo rule
        while (s <= upperboundalpha) && (~cond_alpha)
            unew = max(u-alpha*grad_u,0); 
            % Safety procedure: make sure that we have 
            % unew = u-alpha*grad_u >= 0: 
            % Usually not entered
            if unew == 0
                indgradpos = find(grad_u > 0); 
                alpha = mean(u(indgradpos)./grad_u(indgradpos)); 
                unew = max(u-alpha*grad_u,0); 
            end
            deltau = unew-u;
            if bbbin == 1
                Fnew = -unew'*((1+d)*(B*unew)-d*ones(n,1)*sum(unew))+ ...
                       0.5*(unew'*unew)^2;
            else
                Fnew = -unew'*(B*unew+d*Bbin*unew-d*ones(n,1)*sum(unew))...
                       +0.5*(unew'*unew)^2;
            end
            % Armijo
            cond_alpha = ((Fnew-Fold) <= sigma*grad_u(:)'*deltau(:));
            s = s+1;
            if cond_alpha == 0
                alpha = alpha*beta;
            else
                alpha = alpha/sqrt(beta);
            end
        end
        u = unew;    
        % Stopping criteria, only valid for binary adjacency matrix 
        % otherwise the algorithm is run for maxiter iterations
        precision = 0.05;
        if (sum(u>=1-precision)+sum(u<=precision)==n) && ...
           (max(u) <= 1+precision)
            %I = find(u > 0.5);
            %clqsize = length(I);
            break;
        end
        % Tuning the parameter d
        if k/upperboundupdt == ceil(k/upperboundupdt)
            d = min(gamma*d,D);
        end
    end
    I = find(u > 0.5*min(B(B > 0)));
    % If a clique is not identified, we perform a post processing based on 
    % the entries of u to extract one
    if min(min(B(I,I)))==0
        disp('A clique could not be identified:-');
        disp('not enough iterations or value of D too small.');
        disp('We have post-processed the solution to generate a clique.');
        disp('Instead if you want to extract a dense subgraph,');
        disp('then use, I = find(u > 0.5*min(B(B > 0))).');
        I = extract_clique(B,u);
    end
    clqsize = length(I);
end