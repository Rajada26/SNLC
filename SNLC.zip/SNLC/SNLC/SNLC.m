function [XEST,Time] = SNLC(DD,Xa,d)
    %% ********************************************************************
    %% Code Description:-
    %% Sensor Network Localization Using Cliques
    %  This code can handle both anchorless and with anchor cases.
    %% ********************************************************************
    %% Input:-
    %  Measurement Graph
    %  DD : Distances [(N+K)-by-(N+K) where N: No. of sensors, K: No. of
    %       anchors]
    %  Xa : Anchor positions [d-by-K]
    %  d  : Dimension of the space where sensors are embedded
    %% ********************************************************************
    %% Output:-
    %  Estimated sensors locations
    %  XEST: Estimated sensors locations [d-by-N]
    %  Time: Run-time of the program
    %% ********************************************************************
    %% Checking parallel pool
    parfor i = 1:4
        fprintf('RSNLC is ready to execute.');
    end
    tic;
    %% Main Program
    if nargin ~= 3
        error('Number of inputs must be three.');
    end
    K = size(Xa,2);                                  % No. of anchors
    N = length(DD)-K;                                % No. of sensors
    if K ~= 0
        lam = 1;                         % Parameter for GRET-SDP/GRET-SPEC
    else
        lam = 0;
    end
    rho = 1e-2;                                      % ADMM parameter
    %% Phase- I: Cliques extraction and localization
    %% Part - A: Extract a clique from the neighborhood graph of each node.
    A   = sign(DD);                                  % Adjacency matrix
    Clq = Clique_Create(A);                          % Nodes in the cliques
    if length(Clq) > 1
    %% Part - B: Checking for the clique system and rectify it
    Clq = clq_system_check(Clq,d,N,A);
    %% Part - C: Localization + Refinement + C Build Up [Parallel Coding]
    M = length(Clq);                                   % No. of cliques
    disp('Number of cliques: ');
    disp(M);
    %  Defining variables for parallel computation
    %  Variables for clique localization
    DD1 = cell(M,1);
    Xa1 = cell(M,1);
    %  Variables for C build up
    J1 = cell(M,1);
    J2 = cell(M,1);
    B1 = cell(M,1);
    B2 = cell(M,1);
    D1 = cell(M,1);
    D2 = cell(M,1);
    for i = 1:M
        DD1{i} = DD(Clq{i},Clq{i});
        a      = Clq{i}(Clq{i} > N);
        if isempty(a)
            Xa1{i} = [];
        else
            Xa1{i} = Xa(:,a-N);
        end
    end
    %% Localization + C Build Up Step- 1
    parfor i = 1:M
        PLoc = ClqLoc(Clq{i},DD1{i},Xa1{i},d);
        [J1{i},J2{i},B1{i},B2{i},D1{i},D2{i}] = Compute_matices...
                                                    (Clq{i},PLoc,N,lam);
    end
    clearvars DD1 Xa1                                % Clear variables
    %% Phase- II: Clique Registration
    %% C Build Up Step- 2
    %% Final J computation
    J     = sparse(N+M,N+M);
    J1mat = cell2mat(J1');
    J2mat = cell2mat(J2);
    J(1:N,1:N)         = diag(sum(J1mat,2));
    J(1:N,N+(1:M))     = -J1mat;
    J(N+(1:M),1:N)     = -J1mat';
    J(N+(1:M),N+(1:M)) = diag(J2mat);
    J = full(J);
    clearvars J1mat J2mat J1 J2                      % Clear variables
    %% Final B computation
    if lam ~= 0
        B                    = sparse((M+1)*d,N+M);
        B(M*d+(1:d),N+(1:M)) = cell2mat(B2');
    else
        B = sparse(M*d,N+M);
    end
    B(1:(M*d),1:N) = cell2mat(B1);
    %% Final D computation
    if lam ~= 0
        D     = sparse((M+1)*d,(M+1)*d);
        D2mat = cell2mat(D2);
        D(1:(M*d),M*d+(1:d)) = D2mat;
        D(M*d+(1:d),1:(M*d)) = D2mat';
    else
        D = sparse(M*d,M*d);
    end
    for i = 1:M
        B((i-1)*d+(1:d),N+i) = -(sum(B1{i},2)+B2{i});
        D((i-1)*d+(1:d),(i-1)*d+(1:d)) = D1{i};
        if lam ~= 0
            D(M*d+(1:d),M*d+(1:d)) = D(M*d+(1:d),M*d+(1:d))-D2{i};
        end
    end
    clearvars B1 B2                                  % Clear variables
    if lam ~= 0
        clearvars D2mat D1 D2                        % Clear variables
    else
        clearvars D1 D2                              % Clear variables
    end
    D     = (D+D')/2;
    %% C computation
    BJinv = B*pinv(J);
    C     = D-BJinv*B';
    C     = (C+C')/2;
    %% Part - A : Solving Clique Registration Problem
    %% GRET-SDP using ADMM initialization done by approx. GRET-SPEC
    [G,~] = GRET_SDP_ADMM(C,d,rho);
    %% Eigenvector rounding
    [V,e] = eig(G);
    [e,I] = sort(diag(e),'descend');
    e     = e(1:d);
    e     = max(e,0);
    e     = diag(e);
    V     = V(:,I(1:d));
    U     = sqrt(e)*V';
    %% O(d) recovery from U
    O = Odrecovery(U);
    %% Position Estimation
    XEST = O*BJinv;
    if lam ~= 0
        XEST = O(:,M*d+(1:d))'*XEST;
    end
    XEST = XEST(:,1:N);
    %% Part - B : Final Refinement
    DD1       = DD(1:N,:);
    [XEST,~]  = Refinepositions(XEST,Xa,DD1);
    XEST      = XEST(:,1:N);
    else
        Loc  = ClqLoc(1:(N+K),DD,Xa,d);
        XEST = Loc(:,1:N);
    end
    Time = toc;
end