%% ************************************************************************
%% Code Description:-
%  Clique Localization + Refinement - having or without having anchors
%  CASE-1: Having Anchors
%  Projected gradient descent algorithm with Armijo rule has been used to
%  solve the problem.
%  For the initialization, we have used muli-dimensional scaling (MDS)
%  algorithm and Arun's Global Registration method.
%  CASE-2: Without Having Anchors
%  Solve MDS.
%  Finally refinement is done.
%% Input :-
%  P     : Node numbers in a clique
%  DD    : Distance matrix
%  Xa    : Anchor positions in column format
%  d     : Dimension of the space
%% Output:-
%  Xest  : Estimated position of the nodes
%  node  : Node number in a sorted order
%% ************************************************************************
function Xest = ClqLoc(P,DD,Xa,d)
    if nargin ~= 4
        error('Number of inputs must be equal to four.')
    end
    if any(diag(DD) ~= 0)
        error('Diagonal of the distance matrix must be zeros.')
    end
    [~,K] = size(Xa);                % K : Number of anchors in the patch
    if length(P) == K
        Xest  = Xa;
    else
        Xest  = MDS(DD,d);
        Nt    = length(P);           % Nt: Total number of nodes
        N     = Nt-K;                % N : Number of sensors
        DD    = DD(1:N,1:Nt);
        if K == 1
            Xest = Xest(:,1:N)+(Xa-Xest(:,N+1))*ones(1,N);
            Xest = real(Xest);
        elseif K > 1
            X1        = Xest(:,N+(1:K));
            [~,~,O,t] = Globalregistration_Arun(X1,Xa);
            Xest      = O*Xest(1:d,1:N)+t*ones(1,N);
        end
    end
    [Xest,~] = Refinepositions(Xest,Xa,DD);
end