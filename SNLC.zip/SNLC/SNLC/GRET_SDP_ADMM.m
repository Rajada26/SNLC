%% Solving GRET-SDP using Alternating Direction Method of Multipliers
%% Function description:-
%  Solving ``Patch Registration Problem'' using ADMM Gauss Seidel update
%  is used to find the Gram matrix
%% Input:-
%  C  : A constant symmetric PSD matrix- C=D-B*pinv(J)*B'
%  d  : Dimension of the space where the sensors are embedded
%  rho: Parameter for ADMM
%% Output:-
%  obj: Objective function value- Tr(CG)
%  Xk : Md-by-Md matrix- Xk= O'O where O=[O1 ... OM]: Oi represents the 
%       ith patch rotation matrix    
%% Description of the parameters
%  Xk : Primal variable
%  Yk : Primal variable [variable splitting]
%  Mk : Dual variable
%  ita: Total number of iteration
%  k  : Iteration number
%  d  : Dimension of the space where sensors are embedded
function[Xk,obj] = GRET_SDP_ADMM(C,d,rho)
    %% Stopping criteria
    ita      = 1000;
    epsiabs  = 1e-5;
    epsirel  = 1e-5;
    %% Initialization of parameters
    k   = 0;
    M   = length(C);
    M   = M/d;
    %% Initialization for Yk and Mk [when k = 0]
    Mk    = zeros(M*d);
    [~,W] = GRET_SDP_SPEC(C,d);
    O     = Odrecovery(W);
    Yk    = O'*O;
    obj   = [];
    %% GRET-ADMM
    count = 0;
    obj0  = trace(C*Yk);
    while k < ita
        Yo = Yk;
        %% Updating Xk
        %  Solving min ||X-Xc||^2_F
        Xc = Yk-(C-Mk)/rho;
        [Uk,Ek] = eig(Xc);
        %  Projecting X* on the set of PSD matrices(S^{Md}_+)
        Ek = diag(Ek);
        Ek(Ek < 0) = 0;
        Ek = sparse(1:M*d,1:M*d,Ek);
        Xk = Uk*Ek*Uk';
        %% Updating Yk
        %  Solving min ||Y-Yc||^2_F
        Yc = Xk-Mk/rho;
        Yk = Yc;
        %  Projecting Y* on Omega- diagonal blocks are identity
        for i = 0:(M-1)
            Yk(i*d+(1:d),i*d+(1:d)) = eye(d);
        end
        %% Updating Mk
        Mk = Mk-rho*(Xk-Yk);
        %% Objective function value
        k   = k+1;
        obj = [obj trace(C*Xk)];
        %% Tolarence Calculation
        epsipri  = M*epsiabs+epsirel*max(norm(Xk,'fro'),norm(Yk,'fro'));
        epsidual = M*epsiabs+epsirel*norm(Xk,'fro');
        %% Stoping criterion
        respri  = norm(Xk-Yk,'fro');
        resdual = norm(rho*(Yk-Yo),'fro');
        if epsipri > respri && epsidual > resdual
            break
        end
        if abs(obj(k)-obj0) < 1e-5*obj0
            count = count+1;
        else
            count = 0;
            obj0  = obj(k);
        end
        if count == 10
            break
        end
    end
    disp('No. of iterations: ');
    disp(k)
    disp('Final obective value: ');
    disp(obj(k))
    Xk  = real((Xk+Xk')/2);
end