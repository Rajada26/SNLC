function [obj,W] = GRET_SDP_SPEC(C,d)
    %% --------------------------------------------------------------------
    %% Solving GRET-SDP using Spectral Decomposition
    %% Function description:-
    %  Solving ``Patch Registration Problem'' using Spectral Decomposition
    %% Input:-
    %  C  : A constant symmetric PSD matrix- C=D-B*pinv(J)*B'
    %  d  : Dimension of the space where the sensors are embedded
    %% Output:-
    %  obj: Objective function value- Tr(CG)
    %  G : Md-by-Md Gram matrix- Xk= O'O where O=[O1 ... OM]: Oi represents
    %      the ith patch rotation matrix
    %% --------------------------------------------------------------------
    M     = length(C);
    M     = M/d;
    [V,E] = eig(C);
    [e,I] = sort(diag(E));
    V     = V(:,I(1:d));
    %% W and objective value computation
    W   = sqrt(M)*V';
    obj = M*sum(e(1:d));
    disp('Spectral objective value: ');
    disp(obj);
end